﻿// See https://aka.ms/new-console-template for more information



using compositepattern;

var rootFolder = new compositepattern.Folder("RootFolder");
var rootFile = new compositepattern.File("rootfile", 100);
var folder1= new compositepattern.Folder("folder1");
var folder2= new compositepattern.Folder("folder2");

rootFolder.Add(rootFile);
rootFolder.Add(folder1);
rootFolder.Add(folder2);

var folder1file1 = new compositepattern.File("folder1file1", 300);
var folder1file2 = new compositepattern.File("folder1file2", 300);
var folder2file = new compositepattern.File("folder2file", 500);
folder1.Add(folder1file1);
folder1.Add(folder1file2);
folder2.Add(folder2file);

Console.WriteLine(rootFolder.GetSize());
Console.WriteLine(folder1.GetSize());
Console.WriteLine(folder2.GetSize());