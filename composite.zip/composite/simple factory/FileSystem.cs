﻿namespace compositepattern
{
    public abstract class FileSystemItem
    {
        public string Name { get; set; }
        public abstract long GetSize();

        public FileSystemItem(string name)
        {
            Name = name;   
        }
    }

    public class File : FileSystemItem
    {
        private readonly long _size;

        public File(string name,long size):base(name)
        {
            _size = size;
        }

        public override long GetSize()
        {
            return _size;
        }
    }


    public class Folder : FileSystemItem
    {
        private List<FileSystemItem> _fileSystemItem { get; set; } = new();

      
        public Folder(string name):base(name)
        {
        }

        public void Add(FileSystemItem itemToAdd)
        {
            _fileSystemItem.Add(itemToAdd);
        }

        public void Remove(FileSystemItem itemToAdd)
        {
            _fileSystemItem.Remove(itemToAdd);
        }

        public override long GetSize()
        {
            var totalsize = 0L;
            _fileSystemItem.ForEach(fileItem => {
                totalsize += fileItem.GetSize();
            });
            return totalsize;
        }
    }
}
